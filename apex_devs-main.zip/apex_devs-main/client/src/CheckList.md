# Functionalities to add

- Search Bar in homepage
- Confirm Password
- Remember me
- Project delete
- Add comments 
- Add like/dislike 
- Developer Follow option
- Small popup on profile icon to - view profile - edit profile - uploaded project- log out option
- small nav bar in profile page to navigate to profile - uploads 
